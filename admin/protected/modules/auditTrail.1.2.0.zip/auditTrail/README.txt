In your main.php config file, add the follow line in your modules section:


	'modules'=>array(
		..		
		'auditTrail'=>array(),
		..


Then go to 

http://myapp.com/index.php?r=auditTrail


and view the instructions for setup!

For a more detailed walkthrough, please see the instructions at

http://www.yiiframework.com/extension/audittrail